// --- CORE SETTINGS ---
var iterations = 64;
declareattribute("iterations", { type: "long", min: 1, max: 512, default: 64 });

// --- HARMONY & RANGE ---
var root = 60;          // C4
declareattribute("root", { type: "long", min: 0, max: 127, default: 60 });

var scaleType = 1;      // 0 major, 1 minor, 2 dorian, 3 minor pentatonic
declareattribute("scaleType", { type: "long", min: 0, max: 3, default: 1 });

var minPitch = 48;
declareattribute("minPitch", { type: "long", min: 0, max: 127, default: 48 });

var maxPitch = 84;
declareattribute("maxPitch", { type: "long", min: 0, max: 127, default: 84 });

var maxMelodicLeap = 12;
declareattribute("maxMelodicLeap", { type: "long", min: 1, max: 24, default: 12 });

// --- PHRASING & RHYTHM ---
var bars = 4;
declareattribute("bars", { type: "long", min: 1, max: 64, default: 4 });

var beatsPerBar = 4;

var phraseVariations = 4;
declareattribute("phraseVariations", { type: "long", min: 1, max: 16, default: 4 });

var restProbability = 0.16;
declareattribute("restProbability", { type: "float", min: 0.0, max: 0.8, default: 0.16 });

var swing = 0.0;        // 0..0.25, late offset on off-eighths
declareattribute("swing", { type: "float", min: 0.0, max: 0.25, default: 0.0 });

// --- SCORING WEIGHTS ---
var repeatPenalty = 2.0;
declareattribute("repeatPenalty", { type: "float", min: 0.0, max: 10.0, default: 2.0 });

var cadenceStrength = 4.0;
declareattribute("cadenceStrength", { type: "float", min: 0.0, max: 10.0, default: 4.0 });

var motifStrength = 2.5;
declareattribute("motifStrength", { type: "float", min: 0.0, max: 10.0, default: 2.5 });

var stepBias = 3.0;
declareattribute("stepBias", { type: "float", min: 0.0, max: 10.0, default: 3.0 });


function log() {
  for (var i = 0, len = arguments.length; i < len; i++) {
    var message = arguments[i];
    if (message && message.toString) {
      var s = message.toString();
      if (s.indexOf("[object ") >= 0) {
        s = JSON.stringify(message);
      }

      post(s);
    } else if (message === null) {
      post("<null>");
    } else {
      post(message);
    }
  }
  post("\n");
}



function msg_dictionary(args) {
  args = args || {};

  var inputNotes = args.notes || [];
  var clip = args.clip || {};

  var totalBeats = getClipLength(clip);
  var basePhraseLength = totalBeats / phraseVariations;
  if (basePhraseLength < beatsPerBar) {
    basePhraseLength = totalBeats;
    phraseVariations = 1;
  }

  var scalePcs = getScalePitchClasses(root, scaleType);
  var chordPcs = extractChordPitchClasses(inputNotes);

  if (chordPcs.length === 0) {
    chordPcs = getDefaultChordPitchClasses(root, scaleType);
  }

  var out = [];
  var motifIntervals = [];

  var firstPitch = pickFirstPitch(chordPcs, scalePcs);

  var possiblePatterns = [
    [1.0, 1.0, 1.0, 1.0], 
    [0.5, 0.5, 1.0, 1.0, 1.0], 
    [1.5, 0.5, 1.0, 1.0], 
    [0.75, 0.25, 1.0, 0.5, 0.5, 1.0], 
    [0.5, 0.25, 0.25, 1.0, 2.0], 
    [0.25, 0.25, 0.5, 1.0, 0.5, 0.5, 1.0] 
  ];
  
  var validPatterns = [];
  for (var pIdx = 0; pIdx < possiblePatterns.length; pIdx++) {
     var sum = 0;
     for (var j = 0; j < possiblePatterns[pIdx].length; j++) sum += possiblePatterns[pIdx][j];
     if (Math.abs(sum - beatsPerBar) < 0.001) validPatterns.push(possiblePatterns[pIdx]);
  }
  
  var rhythmPattern = [1.0, 1.0, 1.0, 1.0];
  if (validPatterns.length > 0) {
    rhythmPattern = validPatterns[Math.floor(Math.random() * validPatterns.length)];
  }

  var firstDuration = rhythmPattern.length > 0 ? rhythmPattern[0] : 1.0;

  out.push({
    pitch: clampMidi(firstPitch),
    start_time: 0,
    duration: firstDuration,
    velocity: chooseVelocity(0, basePhraseLength, true)
  });

  var previousPitch = firstPitch;
  var previousInterval = 0;
  var recentDirections = [];
  var recentPitches = [firstPitch];
  var time = firstDuration;

  for (var i = 0; i < iterations && time < basePhraseLength; i++) {
    var remaining = basePhraseLength - time;
    var phraseProgress = (time % phraseLength) / phraseLength;
    var isPhraseStart = phraseProgress < 0.001;
    var isNearEnd = time >= basePhraseLength - 1.0;

    var currentBar = Math.floor(time / beatsPerBar);
    var duration;
    var isPatternBar = (currentBar % 4 === 0 || currentBar % 4 === 2);

    if (isPatternBar) {
      var timeInBar = time % beatsPerBar;
      var rTimeSum = 0;
      var foundDur = 0;
      var epsilon = 0.001;

      for (var p = 0; p < rhythmPattern.length; p++) {
        if (Math.abs(timeInBar - rTimeSum) < epsilon) {
          foundDur = rhythmPattern[p];
          break;
        }
        rTimeSum += rhythmPattern[p];
      }

      if (foundDur > 0) {
        duration = Math.min(foundDur, remaining);
      } else {
        var nextEvent = beatsPerBar;
        var rTimeSumSync = 0;
        for (var p = 0; p < rhythmPattern.length; p++) {
          rTimeSumSync += rhythmPattern[p];
          if (rTimeSumSync > timeInBar + epsilon) {
            nextEvent = rTimeSumSync;
            break;
          }
        }
        duration = Math.min(nextEvent - timeInBar, remaining);
      }
    } else {
      duration = chooseDuration(remaining, phraseProgress, phraseLength, isPhraseStart);

      var nextBarStart = (currentBar + 1) * beatsPerBar;
      var isNextBarPattern = ((currentBar + 1) % 4 === 0 || (currentBar + 1) % 4 === 2);
      if (isNextBarPattern && (time + duration) > nextBarStart) {
        duration = nextBarStart - time;
      }
    }

    if (!isNearEnd && !isPhraseStart && Math.random() < restProbability) {
      time = snapTime(time + duration);
      continue;
    }

    var pitch = chooseNextPitch(
      previousPitch,
      previousInterval,
      time,
      basePhraseLength,
      phraseLength,
      scalePcs,
      chordPcs,
      motifIntervals,
      recentDirections,
      recentPitches
    );

    var velocity = chooseVelocity(time, phraseLength, isStrongBeat(time));

    out.push({
      pitch: clampMidi(pitch),
      start_time: applySwing(snapTime(time)),
      duration: duration,
      velocity: velocity
    });

    var interval = pitch - previousPitch;

    var dir = interval > 0 ? 1 : (interval < 0 ? -1 : 0);
    if (dir !== 0) {
      recentDirections.push(dir);
      if (recentDirections.length > 3) recentDirections.shift();
    }

    // Capture the opening contour as the motif.
    if (motifIntervals.length < 4 && interval !== 0) {
      motifIntervals.push(interval);
    }

    previousInterval = interval;
    previousPitch = pitch;
    recentPitches.push(pitch);
    if (recentPitches.length > 4) recentPitches.shift();
    time = snapTime(time + duration);
  }

  var finalOut = [];
  
  for (var v = 0; v < phraseVariations; v++) {
    var isFinalVariation = (v === phraseVariations - 1);
    var variationNotes = JSON.parse(JSON.stringify(out));
    
    // Apply Mutations
    if (v === 1) { // Rhythmic Syncopation
      for (var n = 0; n < variationNotes.length; n++) {
        var note = variationNotes[n];
        var beatInBar = note.start_time % beatsPerBar;
        if (Math.abs(beatInBar) < 0.001 && note.duration >= 0.5 && note.start_time > 0) {
          note.start_time -= 0.25;
          note.duration += 0.25;
        }
      }
    } else if (v === 2) { // Passing Tones
      var mutated = [];
      for (var n = 0; n < variationNotes.length; n++) {
        var note = variationNotes[n];
        mutated.push(note);
        if (n < variationNotes.length - 1 && note.duration >= 0.5) {
          var nextNote = variationNotes[n + 1];
          var interval = nextNote.pitch - note.pitch;
          if (Math.abs(interval) === 3 || Math.abs(interval) === 4) {
            var dir = interval > 0 ? 1 : -1;
            var pPitch = note.pitch + dir;
            var limit = 6;
            while (!contains(scalePcs, mod12(pPitch)) && Math.abs(pPitch - note.pitch) <= 4 && limit-- > 0) {
               pPitch += dir;
            }
            if (pPitch !== note.pitch && pPitch !== nextNote.pitch && contains(scalePcs, mod12(pPitch))) {
               var originalDuration = note.duration;
               note.duration = originalDuration / 2;
               
               var passingNote = Object.assign({}, note);
               passingNote.pitch = pPitch;
               passingNote.start_time = note.start_time + note.duration;
               passingNote.duration = originalDuration / 2;
               passingNote.velocity = Math.max(30, note.velocity - 10);
               mutated.push(passingNote);
            }
          }
        }
      }
      variationNotes = mutated;
    }

    if (isFinalVariation && phraseVariations >= 4) {
      var canShiftUp = true;
      for (var n = 0; n < variationNotes.length; n++) {
        if (variationNotes[n].pitch + 12 > maxPitch) canShiftUp = false;
      }
      if (canShiftUp) {
        for (var n = 0; n < variationNotes.length; n++) variationNotes[n].pitch += 12;
      }
    }
    
    var targetPc = isFinalVariation ? mod12(root) : mod12(root + 7);
    forceCadence(variationNotes, basePhraseLength, scalePcs, chordPcs, targetPc);
    
    var offset = v * basePhraseLength;
    for (var n = 0; n < variationNotes.length; n++) {
      variationNotes[n].start_time += offset;
      if (variationNotes[n].start_time < totalBeats) {
        finalOut.push(variationNotes[n]);
      }
    }
  }

  outlet_dictionary(0, { notes: finalOut });
  log(finalOut);
}


function chooseNextPitch(previousPitch, previousInterval, time, totalBeats, phraseLength, scalePcs, chordPcs, motifIntervals, recentDirections, recentPitches) {
  var prevPc = mod12(previousPitch);
  var prevIsNonScale = !contains(scalePcs, prevPc);

  var candidates = [];
  for (var p = minPitch; p <= maxPitch; p++) {
    if (Math.abs(p - previousPitch) > maxMelodicLeap) continue;
    
    var isScaleTone = contains(scalePcs, mod12(p));
    
    if (prevIsNonScale) {
      if (isScaleTone && Math.abs(p - previousPitch) === 1) {
        candidates.push(p);
      }
    } else {
      if (isScaleTone) {
        candidates.push(p);
      } else {
        if (Math.abs(p - previousPitch) === 1) {
          candidates.push(p);
        }
      }
    }
  }

  if (candidates.length === 0) {
    for (var fp = minPitch; fp <= maxPitch; fp++) {
      if (contains(scalePcs, mod12(fp)) && Math.abs(fp - previousPitch) <= maxMelodicLeap) {
        candidates.push(fp);
      }
    }
    if (candidates.length === 0) candidates.push(previousPitch);
  }

  var globalProgress = totalBeats <= 0 ? 0 : time / totalBeats;
  var phraseProgress = (time % phraseLength) / phraseLength;
  var nearEnding = globalProgress > 0.82;
  var nearPhraseEnd = phraseProgress > 0.75;

  var phraseArc = Math.sin(phraseProgress * Math.PI) * 6;
  var globalArc = Math.sin(globalProgress * Math.PI) * 4;
  var contourTarget = root + 5 + phraseArc + globalArc;

  var weighted = [];

  var sumDir = 0;
  if (recentDirections && recentDirections.length === 3) {
    sumDir = recentDirections[0] + recentDirections[1] + recentDirections[2];
  }
  var trendingUp = sumDir === 3;
  var trendingDown = sumDir === -3;

  for (var c = 0; c < candidates.length; c++) {
    var pitch = candidates[c];
    var interval = pitch - previousPitch;
    var absInterval = Math.abs(interval);
    var pc = mod12(pitch);
    var currentDir = interval > 0 ? 1 : (interval < 0 ? -1 : 0);

    var score = 100.0;

    var isScaleTone = contains(scalePcs, pc);
    var isTension = !isScaleTone;

    var beatInBar = time % beatsPerBar;
    var isBeat1 = Math.abs(beatInBar - 0) < 0.001;
    var isBeat3 = Math.abs(beatInBar - 2) < 0.001;
    var isOffBeat = beatInBar % 1 > 0.001;

    var intervalFromRoot = mod12(pc - root);
    var isPrimary = (intervalFromRoot === 0 || intervalFromRoot === 7);
    var isSecondary = (intervalFromRoot === 3 || intervalFromRoot === 4 || intervalFromRoot === 10 || intervalFromRoot === 11);
    var isPassing = isScaleTone && !isPrimary && !isSecondary;

    if (isTension) {
      if (isOffBeat) score -= 180.0;
      else score -= 1000.0;
    } else {
      if (isPrimary && isBeat1) score += 100.0;
      if (isSecondary && isBeat3) score += 60.0;
      if (isPassing) {
        if (isOffBeat) score += 40.0;
        else score -= 50.0;
      }
    }

    if (absInterval === 0) {
      score -= 200.0;
    } else if (absInterval <= 2) {
      score += 120.0;
    } else if (absInterval <= 4) {
      score += 40.0;
    } else if (absInterval <= 7) {
      score -= 30.0;
    } else {
      score -= 120.0;
    }

    if (pitch === previousPitch) score -= repeatPenalty * 10;
    
    if (recentPitches && recentPitches.length >= 2 && pitch === recentPitches[recentPitches.length - 2]) {
      score -= 500.0;
    }

    if (trendingUp) {
      if (currentDir > 0) score += 30.0;
      else if (currentDir < 0) score -= 10.0;
    } else if (trendingDown) {
      if (currentDir < 0) score += 30.0;
      else if (currentDir > 0) score -= 10.0;
    }

    var center = root + 7;
    score -= Math.abs(pitch - center) * 6.0;
    score -= Math.abs(pitch - contourTarget) * 4.0;

    if (Math.abs(previousInterval) > 7) {
      if (currentDir === -Math.sign(previousInterval) && isScaleTone && absInterval <= 2) {
        score += 500.0;
      } else {
        score -= 1000.0;
      }
    } else if (Math.abs(previousInterval) >= 5) {
      if (currentDir === -Math.sign(previousInterval) && isScaleTone && absInterval <= 4) {
        score += 100.0;
      }
    }

    if (motifIntervals.length > 0) {
      var motifInterval = motifIntervals[(time | 0) % motifIntervals.length];
      if (interval === motifInterval) score += motifStrength;
      else if (interval === -motifInterval) score += motifStrength * 0.5;
    }

    if (nearPhraseEnd) {
      if (contains(chordPcs, pc)) score += 2.0;
      if (pc === mod12(root)) score += 1.0;
    }

    if (nearEnding) {
      if (contains(chordPcs, pc)) score += cadenceStrength;
      if (pc === mod12(root)) score += cadenceStrength * 1.5;
    }

    weighted.push({ value: pitch, weight: Math.max(0.01, score) });
  }

  return weightedChoice(weighted);
}


function chooseDuration(remaining, phraseProgress, phraseLength, isPhraseStart) {
  // Bias longer durations at phrase starts and shorter, livelier figures mid-phrase.
  var options;

  if (isPhraseStart) {
    options = [
      { value: 0.5, weight: 3.0 },
      { value: 0.75, weight: 1.5 },
      { value: 1.0, weight: 4.0 },
      { value: 1.5, weight: 2.0 },
      { value: 2.0, weight: 1.0 }
    ];
  } else if (phraseProgress > 0.75) {
    options = [
      { value: 0.25, weight: 1.0 },
      { value: 0.5, weight: 4.0 },
      { value: 1.0, weight: 3.0 },
      { value: 1.5, weight: 1.5 }
    ];
  } else {
    options = [
      { value: 0.25, weight: 3.5 },
      { value: 0.5, weight: 5.0 },
      { value: 0.75, weight: 1.5 },
      { value: 1.0, weight: 2.5 },
      { value: 1.5, weight: 1.0 }
    ];
  }

  var possible = [];
  for (var i = 0; i < options.length; i++) {
    if (options[i].value <= remaining) possible.push(options[i]);
  }

  if (possible.length === 0) return remaining;
  return weightedChoice(possible);
}


function chooseVelocity(time, phraseLength, strongBeat) {
  var phraseProgress = (time % phraseLength) / phraseLength;
  var arc = Math.sin(phraseProgress * Math.PI);   // peak mid-phrase
  var base = 72 + arc * 22;

  if (strongBeat) base += 8;

  var v = Math.round(base + randomInt(-5, 5));
  if (v < 30) v = 30;
  if (v > 124) v = 124;
  return v;
}


function forceCadence(out, totalBeats, scalePcs, chordPcs, targetPc) {
  if (targetPc === undefined) targetPc = mod12(root);

  var cadenceStart = Math.max(0, totalBeats - 1);
  var penultimateStart = Math.max(0, totalBeats - 1.5);

  // Keep notes that finish at or before the penultimate point.
  var cleaned = [];
  for (var i = 0; i < out.length; i++) {
    var note = out[i];
    var noteEnd = note.start_time + note.duration;
    if (note.start_time < penultimateStart && noteEnd <= penultimateStart + 0.001) {
      cleaned.push(note);
    }
  }

  var anchor = cleaned.length > 0 ? cleaned[cleaned.length - 1].pitch : root;
  var tonic = nearestPitchWithPc(anchor, targetPc);

  var dir = anchor > tonic ? -1 : 1;
  var penultimatePc;
  
  if (targetPc === mod12(root)) {
    var leadingPc = mod12(tonic - 1);
    var supertonicPc = mod12(tonic + 2);
    if (contains(scalePcs, leadingPc)) {
      penultimatePc = leadingPc;
    } else if (contains(scalePcs, supertonicPc)) {
      penultimatePc = supertonicPc;
    } else {
      penultimatePc = mod12(tonic - 2);
    }
  } else {
    var pPitch = tonic - dir;
    var limit = 12;
    while (!contains(scalePcs, mod12(pPitch)) && limit-- > 0) pPitch -= dir;
    penultimatePc = mod12(pPitch);
  }

  var penultimatePitch = nearestPitchWithPc(tonic, penultimatePc);
  if (penultimatePitch === tonic) penultimatePitch = tonic - dir; // fallback

  cleaned.push({
    pitch: clampMidi(penultimatePitch),
    start_time: roundTime(penultimateStart),
    duration: 0.5,
    velocity: 86
  });

  cleaned.push({
    pitch: clampMidi(tonic),
    start_time: roundTime(cadenceStart),
    duration: 1,
    velocity: 92
  });

  out.length = 0;
  for (var j = 0; j < cleaned.length; j++) out.push(cleaned[j]);
}


function pickFirstPitch(chordPcs, scalePcs) {
  // Start on a chord tone near the middle of the range, preferring the root.
  var rootPc = mod12(root);
  var center = root;

  var candidates = [];
  for (var p = minPitch; p <= maxPitch; p++) {
    var pc = mod12(p);
    if (!contains(scalePcs, pc)) continue;
    if (!contains(chordPcs, pc)) continue;

    var weight = 1.0 - Math.abs(p - center) * 0.05;
    if (pc === rootPc) weight += 1.5;
    candidates.push({ value: p, weight: Math.max(0.05, weight) });
  }

  if (candidates.length === 0) return nearestScalePitch(root, scalePcs);
  return weightedChoice(candidates);
}


function isStrongBeat(time) {
  var rounded = Math.round(time * 1000) / 1000;
  var beat = modN(rounded, beatsPerBar);
  var half = beatsPerBar / 2;
  return Math.abs(beat) < 0.001 || Math.abs(beat - half) < 0.001;
}


function snapTime(t) {
  // Quantise to the sixteenth-note grid to avoid drift across many notes.
  return Math.round(t * 4) / 4;
}


function applySwing(t) {
  if (swing <= 0) return roundTime(t);
  var sixteenth = Math.round(t * 4);
  // Late offset on the second and fourth sixteenth of each beat.
  if (sixteenth % 2 === 1) {
    return roundTime(t + swing * 0.25);
  }
  return roundTime(t);
}


function getScalePitchClasses(rootPitch, type) {
  var intervals;
  if (type === 0) intervals = [0, 2, 4, 5, 7, 9, 11];           // major
  else if (type === 1) intervals = [0, 2, 3, 5, 7, 8, 10];      // natural minor
  else if (type === 2) intervals = [0, 2, 3, 5, 7, 9, 10];      // dorian
  else intervals = [0, 3, 5, 7, 10];                            // minor pentatonic

  var pcs = [];
  var rootPc = mod12(rootPitch);
  for (var i = 0; i < intervals.length; i++) pcs.push(mod12(rootPc + intervals[i]));
  return pcs;
}


function getDefaultChordPitchClasses(rootPitch, type) {
  var rootPc = mod12(rootPitch);
  if (type === 0) {
    return [rootPc, mod12(rootPc + 4), mod12(rootPc + 7)];
  }
  return [rootPc, mod12(rootPc + 3), mod12(rootPc + 7)];
}


function extractChordPitchClasses(notes) {
  var pcs = [];
  for (var i = 0; i < notes.length; i++) {
    if (notes[i].pitch !== undefined) {
      var pc = mod12(notes[i].pitch);
      if (!contains(pcs, pc)) pcs.push(pc);
    }
  }
  return pcs;
}


function nearestScalePitch(pitch, scalePcs) {
  var best = pitch;
  var bestDistance = 999;
  for (var p = minPitch; p <= maxPitch; p++) {
    if (!contains(scalePcs, mod12(p))) continue;
    var d = Math.abs(p - pitch);
    if (d < bestDistance) { best = p; bestDistance = d; }
  }
  return best;
}


function nearestPitchWithPc(centerPitch, pc) {
  var best = centerPitch;
  var bestDistance = 999;
  for (var p = minPitch; p <= maxPitch; p++) {
    if (mod12(p) !== pc) continue;
    var d = Math.abs(p - centerPitch);
    if (d < bestDistance) { best = p; bestDistance = d; }
  }
  return best;
}


function weightedChoice(items) {
  if (items.length === 0) return root;
  var total = 0;
  for (var i = 0; i < items.length; i++) total += items[i].weight;

  var r = Math.random() * total;
  var sum = 0;
  for (var j = 0; j < items.length; j++) {
    sum += items[j].weight;
    if (r <= sum) return items[j].value;
  }
  return items[items.length - 1].value;
}


function getClipLength(clip) {
  if (clip.loop_end !== undefined && clip.loop_start !== undefined) {
    return Math.max(1, clip.loop_end - clip.loop_start);
  }
  if (clip.duration !== undefined) return Math.max(1, clip.duration);
  if (clip.length !== undefined) return Math.max(1, clip.length);
  return bars * beatsPerBar;
}


function contains(arr, value) {
  for (var i = 0; i < arr.length; i++) if (arr[i] === value) return true;
  return false;
}


function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}


function roundTime(t) {
  return Math.round(t * 1000000) / 1000000;
}


function mod12(n) {
  return ((n % 12) + 12) % 12;
}


function modN(n, m) {
  return ((n % m) + m) % m;
}


function clampMidi(n) {
  if (n < 0) return 0;
  if (n > 127) return 127;
  return n;
}
