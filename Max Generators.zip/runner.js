const fs = require('fs');

global.post = function(s) {
  process.stdout.write(s + '');
};

global.declareattribute = function(name, opts) {
  if (typeof global[name] === 'undefined') {
    global[name] = opts.default;
  }
};

global.outlet_dictionary = function(index, dict) {
  console.log("\n--- GENERATED MELODY ---");
  console.log(JSON.stringify(dict.notes));
};

const code = fs.readFileSync('MelodyGen.js', 'utf8');

// Evaluate the script in the global context
eval(code);

console.log("Running MelodyGen.js...");
// Run the main function
msg_dictionary({
  notes: [],
  clip: { duration: 16 } // 4 bars * 4 beats
});
