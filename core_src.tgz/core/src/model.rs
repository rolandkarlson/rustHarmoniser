use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Debug, Clone, Copy)]
pub struct Note {
    pub pitch: i32,
    pub start: f64,
    pub duration: f64,
    pub velocity: i32,
    pub muted: i32, // 0 or 1
    pub channel: i32,
    pub probability: i32,
}

impl Note {
    pub fn new(pitch: i32, start: f64, duration: f64, velocity: i32, muted: i32, channel: i32) -> Self {
        Self {
            pitch,
            start,
            duration,
            velocity,
            muted,
            channel,
            probability: 0,
        }
    }
}

/// One deterministic transformation applied to a later fugue subject entry.
/// Every entry is derived from the original imported subject.
#[derive(Serialize, Deserialize, Debug, Clone, Copy, PartialEq)]
pub struct FugueTransformation {
    #[serde(default)]
    pub invert: bool,
    #[serde(default = "default_one_f64")]
    pub time_scale: f64,
}

impl FugueTransformation {
    pub fn new(invert: bool, time_scale: f64) -> Self {
        Self { invert, time_scale }
    }
}

#[derive(Clone, Serialize, Deserialize)]
pub struct Config {
    pub schillinger_progression: bool,
    /// Try all seven modes for each chord bar, retaining changes that improve
    /// the total render score. The existing root and degree sequence are kept.
    #[serde(default)]
    pub search_other_scales: bool,
    pub last_note_exist_in_voice: f64,
    pub same_direction: f64,
    pub consecutive_octav_fift: f64,
    /// Penalty for historical overlap/clearance and for crossing another voice
    /// in the selected voicing, including notes that are already sustaining.
    pub no_crossing: f64,
    pub last_note_same: f64,
    pub mode: i32,
    pub interval_exists_in_harmony: f64,
    // New fields
    pub voice_rhythm: Vec<f64>,
    /// Optional repeating duration cycle per voice, in beats. Empty/missing or
    /// invalid rows fall back to the lattice/rhythm contour. Valid cycles take
    /// priority over those controls, but Schillinger rhythm generators override
    /// them. Cycles keep absolute timing when split at bar boundaries.
    #[serde(default)]
    pub voice_rhythm_patterns: Vec<Vec<f64>>,
    pub schillinger_sequence: Vec<i32>,
    pub pl: i32,
    pub harmony_distance_balance: f64,
    pub lookahead_depth: i32,
    /// Outer beam search over chord progressions: how many partial progressions
    /// survive each group, AND how many alternative voicings each one branches
    /// into for the next group (same knob for both). 1 = greedy — every group
    /// takes its locally best chord and `lookahead_depth` has no effect, since
    /// there is nothing to rank. Cost per group grows as beam_width² ×
    /// (1 + lookahead_depth) group scorings, so raise it deliberately.
    #[serde(default = "default_beam_width")]
    pub beam_width: i32,
    pub render_length: i32,
    pub rng_seed: f64,
    pub voice_contour: Option<Vec<Vec<i32>>>,
    pub voice_rhythm_contour: Option<Vec<Vec<f64>>>,
    pub voice_contour_resolution: f64,
    pub chord_structure: Vec<i32>,
    pub harmony_distance_contour: Option<Vec<f64>>,
    pub mode_contour: Option<Vec<f64>>,
    /// Key root (tonic pitch class, 0=C … 11=B) over time — the modulation
    /// contour. When present it overrides the scalar `root` per bar, moving the
    /// Schillinger scale realisation AND every root-keyed scoring term
    /// (tendency tones, leading-tone doubling, the chromatic-scale mask) with
    /// it, so the harmonizer follows the new key instead of pulling back to the
    /// old one. Absent/empty = no modulation, scalar `root` everywhere.
    #[serde(default)]
    pub root_contour: Option<Vec<f64>>,
    pub chord_structure_contour: Option<Vec<Vec<f64>>>,
    pub schillinger_ex_contour: Option<Vec<Vec<f64>>>,
    pub harmony_matrix_contour: Option<Vec<f64>>,
    /// Per-voice, per-step melody-force weight over time (outer = 16 voices,
    /// inner = steps, like `voice_rhythm_contour`). When present and the
    /// selected voice's row is non-empty it overrides the scalar `melody_force`
    /// (sampled like the other contours); otherwise the scalar is used.
    /// See `melody_force` / melody_force_term.
    pub melody_force_contour: Option<Vec<Vec<f64>>>,
    /// 9×12 consonance scoring matrix (style rows × interval columns).
    /// None falls back to the built-in default in harmonizer::HARMONY_MATRIX.
    #[serde(default)]
    pub harmony_matrix: Option<Vec<Vec<f64>>>,
    /// Seven mode slots, each with 1–12 ascending semitone offsets from the
    /// tonic (0 first, all in 0..12). Missing/malformed rows use built-in modes.
    #[serde(default)]
    pub mode_scales: Option<Vec<Vec<i32>>>,
    /// Six chord slots, each with ascending member indices in 0..7, starting
    /// at 0. Indices are multiplied by the expansion before indexing the mode.
    /// Missing/malformed rows use the built-in chord structures.
    #[serde(default)]
    pub chord_structures: Option<Vec<Vec<i32>>>,
    pub main_pitch: i32,
    #[serde(default)]
    pub use_floor: bool,
    #[serde(default)]
    pub use_ceiling: bool,
    #[serde(default)]
    pub use_leading_voice: bool,
    #[serde(default)]
    pub leading_voice_track: i32,
    #[serde(default = "default_leading_clip")]
    pub leading_voice_clip: i32,
    pub use_resolve:bool,
    #[serde(default)]
    pub root: i32,
    /// Group-level common-tone control (relationship to the IMMEDIATELY preceding
    /// chord), distinct from the per-voice last_note_* penalties (a voice's own
    /// melodic history). Penalty subtracted per voice that holds its previous pitch.
    #[serde(default)]
    pub common_tone_penalty: f64,
    /// (Superseded by min/max_voices_changed — kept for snapshot compatibility.)
    /// Soft cap on common tones per chord. -1 disables.
    #[serde(default = "default_neg_one")]
    pub max_common_tones: i32,
    /// Voice-change budget: how many voices may change pitch between consecutive
    /// chords. Enforced by holding the lowest-benefit voices on their previous
    /// pitch (parsimonious voice leading). -1 disables each bound.
    #[serde(default = "default_neg_one")]
    pub min_voices_changed: i32,
    #[serde(default = "default_neg_one")]
    pub max_voices_changed: i32,
    /// "Stickiness": score bonus a NON-leader voice gets for holding its previous
    /// pitch (a common tone). Higher = voices keep common tones unless moving is
    /// clearly more consonant. The leader voice is excluded so it stays free to
    /// move. (Principled replacement for the old +30 unison bonus.)
    #[serde(default = "default_same_note_bonus")]
    pub same_note_bonus: f64,
    /// How strongly the per-voice pitch contour pulls candidates toward its target
    /// pitch (quadratic spring, one octave = full weight). 0 = contour ignored.
    #[serde(default = "default_one_f64")]
    pub voice_contour_weight: f64,
    /// Pitch search window: each voice considers previous pitch ± this many
    /// semitones. In chromatic mode that is the whole candidate set; in
    /// Schillinger mode it restricts the bar's scale tones, with the nearest
    /// tone on each side always kept so a tight range can never strand a voice
    /// (see harmonizer::restrict_to_range). Was a hardcoded 3.
    #[serde(default = "default_candidate_range")]
    pub candidate_range: i32,
    /// Chromatic-mode scale constraint: pitch-class offsets from `root` that
    /// candidates must belong to — `[0,2,4,5,7,9,11]` with root 0 is C major.
    /// Empty (the default) leaves the search truly chromatic. Ignored in
    /// Schillinger mode, whose scales come from the progression layer.
    #[serde(default)]
    pub chromatic_scale: Vec<i32>,
    /// Melodic pressure applied to EVERY voice (unlike the leader-only repeat
    /// penalties): candidates are penalized by how recently/often they appeared
    /// in the voice's last 5 notes (recency-decayed, so A-B-A-B circling is
    /// caught, not just immediate repeats), and stepwise motion (1-2 semitones)
    /// gets a small reward. 0 = off; 1.0 ≈ the magnitude of the other ±1 terms.
    #[serde(default)]
    pub melody_force: f64,
    /// Starting/seed pitches for the 5 generated voices (high → low). Voice 0 is
    /// the leading voice. Editable in the GUI "Start Notes" modal, or fetched from
    /// the last chord of an Ableton clip. Missing/short → falls back per index to
    /// the historical defaults [70, 65, 60, 50, 34].
    #[serde(default = "default_start_notes")]
    pub start_notes: Vec<i32>,
    /// Blend between the H-Matrix style preference and register-aware sensory
    /// roughness in the pairwise consonance term. 0 = pure style/pitch-class,
    /// 1 = pure psychoacoustics. See harmonizer::pair_roughness.
    #[serde(default = "default_roughness_weight")]
    pub roughness_weight: f64,
    /// Scales the root-relative chord-quality term (major vs minor vs
    /// suspended), which is the only part of the harmony score that can tell
    /// chord qualities apart — the pairwise interval multiset cannot. 0 = off.
    #[serde(default = "default_one_f64")]
    pub chord_quality_weight: f64,
    /// Preference for the bass on the chord root: full bonus in root position,
    /// 0.4 with the third in the bass, 0 with the fifth (six-four), -0.3 for a
    /// non-chord tone. 0 = inversions are free; at 1.0 and above the bass stops
    /// taking inversions altogether.
    #[serde(default = "default_root_position")]
    pub root_position_weight: f64,
    /// Reward for doubling the chord root (the first doubling only) and equal
    /// penalty per extra voice on the key's leading tone. 0 = off.
    #[serde(default = "default_root_doubling")]
    pub root_doubling_weight: f64,
    /// Tendency-tone pressure: leading tone up to the global/local tonic;
    /// identified major, minor and diminished chordal sevenths down by step
    /// into the destination chord. Repeated holds retain their source role.
    /// 0 = off. See harmonizer::tendency_term.
    #[serde(default = "default_tendency_weight")]
    pub tendency_weight: f64,
    /// Generate `schillinger_sequence` from the mode's chord-transition table
    /// instead of using the literal sequence: one phrase of `pl` bars per
    /// `render_length`, each closing V → I. See schillinger::gen_cadenced_progression.
    #[serde(default)]
    pub use_generated_progression: bool,
    /// Whitelist of allowed chord structures, each written as pitch-class
    /// offsets from an arbitrary root: `[[0,4,7],[0,3,7]]` permits major and
    /// minor triads on every root and nothing else. A chord passes if its set of
    /// DISTINCT pitch classes equals some template transposed — doublings are
    /// free, so this constrains chord structure, not voicing.
    ///
    /// This is the constraint the H-Matrix cannot express: the matrix scores
    /// every PAIR of voices, so it sees {0,4,7} and {0,4,8} as the same thing.
    /// Empty (the default) leaves chord structure unconstrained.
    #[serde(default)]
    pub chord_templates: Vec<ChordTemplate>,
    /// Metric shaping of the hold bonus: how strongly a voice's stickiness
    /// (same_note_bonus) depends on WHERE in the bar the group falls. On the
    /// downbeat holding earns nothing (moving is free), on weak 16ths it earns
    /// the full bonus — so pitch changes, which become onsets after the
    /// downstream same-pitch merge, gravitate toward strong beats. 0 = flat
    /// bonus everywhere (legacy), 1 = full metric profile. Negative values
    /// invert the profile (changes prefer weak positions = syncopation).
    #[serde(default = "default_metric_hold_strength")]
    pub metric_hold_strength: f64,
    /// Hold-momentum shaping: scales the hold bonus by how long the voice has
    /// already sat on its pitch (relative to its target note length). A voice
    /// that just moved is nudged to keep moving (runs), one that settled is
    /// nudged to stay (sustains), one that overstayed is invited back in.
    /// 0 = off.
    #[serde(default = "default_momentum_weight")]
    pub momentum_weight: f64,
    /// Onset-density pressure toward the rhythm contour's target: when a voice
    /// has changed pitch less often this bar than its target note length
    /// implies, holding gets cheaper to refuse (and vice versa). Only active
    /// with a uniform lattice (lattice_beats > 0) — on the legacy lattice the
    /// grid itself is the target and the term would just tax every hold. 0 = off.
    #[serde(default = "default_density_weight")]
    pub density_weight: f64,
    /// Uniform onset lattice: when > 0, gen_voice emits every note at this
    /// duration (e.g. 0.5 = 8ths) for all voices, and the tension-driven
    /// voice_rhythm_contour becomes a density TARGET scored by density_weight
    /// instead of a hard grid — harmony may move at any lattice point and pays
    /// in score, not in impossibility. 0 (default) keeps the contour-driven
    /// lattice.
    #[serde(default)]
    pub lattice_beats: f64,
    /// One-time allowance for a consonant preparation held continuously into a
    /// 4–3, 7–6 or 9–8 suspension over the actual bass. A reachable resolution
    /// may license its forbidden interval; ordinary soft roughness still applies.
    /// Set both suspension weights to 0 to disable recognition. Schillinger only.
    #[serde(default = "default_suspension_tolerance")]
    pub suspension_tolerance: f64,
    /// Reward for the prepared suspension's downward step onto a chord tone;
    /// also the penalty for abandoning it or holding beyond the next harmonic
    /// change / four beats. Repeated wrong notes and rests do not prepare it.
    /// Set both suspension weights to 0 to disable recognition. Schillinger only.
    #[serde(default = "default_suspension_resolve_bonus")]
    pub suspension_resolve_bonus: f64,
    /// Schillinger rhythm generators: when non-empty, every generated voice's
    /// durations come from the resultant r(a÷b[÷c…]) — the interference
    /// pattern of these periodicities (see schillinger::resultant) — scaled by
    /// `rhythm_unit`. Overrides the lattice and the rhythm contours while set.
    /// `[3,2]` gives 2+1+1+2, `[4,3]` gives 3+1+2+2+1+3. Empty (default) = off.
    #[serde(default)]
    pub rhythm_generators: Vec<i32>,
    /// Beats per resultant unit (0.5 = the pattern counts in 8th notes).
    /// Values <= 0 fall back to 0.5.
    #[serde(default = "default_rhythm_unit")]
    pub rhythm_unit: f64,
    /// Polyrhythmic strata: each voice starts `channel × this` elements further
    /// into the resultant cycle, so the voices interlock instead of attacking
    /// together. 0 (default) = every voice plays the same pattern in phase.
    #[serde(default)]
    pub rhythm_voice_rotation: i32,
    /// Phrase-shaped dynamics: velocities are computed from the phrase/render
    /// tension arch, metric position (downbeats accented, offbeats light), and
    /// melodic direction, instead of the legacy random jitter. Scales how far
    /// velocities swing around the base level. 0 = legacy random velocities.
    #[serde(default = "default_dynamics_weight")]
    pub dynamics_weight: f64,
    /// Cadence awareness: extra scoring pressure on the DOWNBEAT of each
    /// phrase-final tonic bar (bar pl-1, chord root == key tonic) — bass on the
    /// root, a complete triad (third present), soprano on the tonic or third,
    /// and a homorhythmic arrival (voices moving onto the downbeat together).
    /// 0 = cadence bars score like any other bar. Schillinger mode only.
    #[serde(default = "default_cadence_weight")]
    pub cadence_weight: f64,
    /// Loop-seam scoring: when non-zero, the render's FINAL chord is voiced to
    /// lead back into its own FIRST chord — per voice, the wrap transition
    /// (final pitch → opening pitch) is scored with seam smoothness and
    /// tendency-tone resolution, weighted by this. The beginning stays fixed;
    /// the end adapts (no fixed-point iteration). For clips played as loops.
    /// 0 (default) = off.
    #[serde(default)]
    pub loop_wrap_weight: f64,
    /// Phrase echo (motif memory): candidates are rewarded for reproducing the
    /// melodic interval the same voice made one phrase (pl bars) earlier at the
    /// same position — exact interval match earns the full weight, off-by-one
    /// a partial one. Transposition-tolerant, so echoes survive the harmony
    /// changing under them (sequences fall out for free). 0 = off.
    #[serde(default = "default_phrase_echo_weight")]
    pub phrase_echo_weight: f64,
    /// Build a configurable 3–8 voice fugal exposition from the imported
    /// Ableton clip. The legacy
    /// five-voice harmonizer is unchanged while this is false.
    #[serde(default)]
    pub fugue_mode: bool,
    /// Number of fugue voices. Three preserves the original middle–upper–bass
    /// exposition; additional entries extend through lower-register parts.
    #[serde(default = "default_fugue_voice_count")]
    pub fugue_voice_count: i32,
    /// Optional register shifts by channel. Missing entries use the planner's
    /// octave spread. In three-voice mode `fugue_bass_subject_shift` remains
    /// authoritative for snapshot compatibility. A real-answer interval is
    /// added separately to answer entries.
    #[serde(default)]
    pub fugue_voice_register_shifts: Vec<i32>,
    /// Continue after the opening exposition with protected subject entries
    /// that cycle through `fugue_transform_cycle` and all fugue voices.
    #[serde(default)]
    pub fugue_repeat_subject: bool,
    /// Later-entry transformations. Inversion reflects chromatic semitone
    /// intervals around the subject's first sounding pitch; time_scale changes
    /// relative starts, durations and the whole source clip span.
    #[serde(default = "default_fugue_transform_cycle")]
    pub fugue_transform_cycle: Vec<FugueTransformation>,
    /// Distance in beats between successive exposition entries. Zero selects
    /// the imported subject clip length, so entries do not overlap by default.
    #[serde(default = "default_fugue_entry_spacing")]
    pub fugue_entry_spacing: f64,
    /// Literal semitone transposition of the real answer (7 = dominant above).
    #[serde(default = "default_fugue_answer_interval")]
    pub fugue_answer_interval: i32,
    /// Legacy three-voice bass register shift. The GUI also mirrors its value
    /// into the last item of `fugue_voice_register_shifts` for wider fugues;
    /// for direct 4–8 voice configs the vector (or automatic spread) wins.
    #[serde(default = "default_fugue_bass_subject_shift")]
    pub fugue_bass_subject_shift: i32,
    /// Anticipate protected subject/answer notes that begin in another voice
    /// while a generated note will still be sustaining. Zero keeps the former
    /// scoring exactly; positive values penalize future clashes and crossings.
    #[serde(default)]
    pub fugue_subject_anticipation: f64,
    /// Shape the last generated note before a returning subject/answer toward
    /// that entry's first sounding pitch. Zero disables the entry approach.
    #[serde(default)]
    pub fugue_entry_approach: f64,
    /// Quantize every protected subject/answer note at its onset to the nearest
    /// pitch in that voice and bar's Schillinger harmony. Ties prefer the lower
    /// pitch. Ignored outside fugue mode or when Schillinger is disabled.
    #[serde(default)]
    pub fugue_fit_to_scale: bool,
    /// Voices treated as the outer parts by channel-aware scoring. Fugue mode
    /// overrides these with soprano 0 and the selected last voice as bass.
    #[serde(default)]
    pub soprano_voice: i32,
    #[serde(default = "default_bass_voice")]
    pub bass_voice: i32,
    /// Ableton destinations for direct, articulation-preserving fugue export.
    #[serde(default = "default_fugue_output_tracks")]
    pub fugue_output_tracks: Vec<i32>,
    #[serde(default = "default_fugue_output_clip")]
    pub fugue_output_clip: i32,
}

/// One entry in `Config::chord_templates`: a chord's pitch classes relative to an
/// arbitrary root, optionally with how often it should be used.
///
/// Both spellings load — a bare `[0,4,7]`, and `{"pcs":[0,4,7],"weight":0.75}` —
/// so configs and snapshots written before weights existed still deserialize.
/// The bare form means "no stated preference"; see `Config::chord_weights_active`.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum ChordTemplate {
    Bare(Vec<i32>),
    Weighted {
        pcs: Vec<i32>,
        #[serde(default = "default_one_f64")]
        weight: f64,
    },
}

impl ChordTemplate {
    pub fn pcs(&self) -> &[i32] {
        match self {
            Self::Bare(pcs) => pcs,
            Self::Weighted { pcs, .. } => pcs,
        }
    }

    /// The stated weight, or `None` for the bare form.
    pub fn explicit_weight(&self) -> Option<f64> {
        match self {
            Self::Bare(_) => None,
            Self::Weighted { weight, .. } => Some(*weight),
        }
    }

    /// Weight used for apportionment. A negative weight has no meaning here and
    /// would corrupt the highest-averages loop, so it clamps to 0 — "never use".
    pub fn weight(&self) -> f64 {
        self.explicit_weight().unwrap_or(1.0).max(0.0)
    }
}

pub const DEFAULT_START_NOTES: [i32; 5] = [70, 65, 60, 50, 34];
fn default_start_notes() -> Vec<i32> { DEFAULT_START_NOTES.to_vec() }
fn default_leading_clip() -> i32 { 1 }
fn default_neg_one() -> i32 { -1 }
fn default_same_note_bonus() -> f64 { 2.0 }
fn default_one_f64() -> f64 { 1.0 }
fn default_candidate_range() -> i32 { 3 }
fn default_beam_width() -> i32 { 3 }
fn default_roughness_weight() -> f64 { 0.5 }
fn default_root_position() -> f64 { 0.5 }
fn default_root_doubling() -> f64 { 0.5 }
fn default_tendency_weight() -> f64 { 0.5 }
fn default_metric_hold_strength() -> f64 { 0.6 }
fn default_momentum_weight() -> f64 { 0.5 }
fn default_density_weight() -> f64 { 0.5 }
fn default_suspension_tolerance() -> f64 { 0.5 }
fn default_suspension_resolve_bonus() -> f64 { 0.6 }
fn default_rhythm_unit() -> f64 { 0.5 }
fn default_dynamics_weight() -> f64 { 1.0 }
fn default_cadence_weight() -> f64 { 0.5 }
fn default_phrase_echo_weight() -> f64 { 0.4 }
fn default_fugue_entry_spacing() -> f64 { 0.0 }
fn default_fugue_voice_count() -> i32 { 3 }
fn default_fugue_answer_interval() -> i32 { 7 }
fn default_fugue_bass_subject_shift() -> i32 { -12 }
fn default_bass_voice() -> i32 { 4 }
fn default_fugue_output_tracks() -> Vec<i32> { vec![4, 5, 6] }
fn default_fugue_output_clip() -> i32 { 2 }
fn default_fugue_transform_cycle() -> Vec<FugueTransformation> {
    vec![
        FugueTransformation::new(true, 1.0),
        FugueTransformation::new(false, 2.0),
        FugueTransformation::new(true, 2.0),
        FugueTransformation::new(false, 1.0),
    ]
}

impl Default for Config {
    fn default() -> Self {
        Self {
            schillinger_progression: true,
            search_other_scales: false,
            // Rescaled for the normalized ([-1,1]) harmony/distance scoring.
            last_note_exist_in_voice: 1.0,
            same_direction: 1.0,
            consecutive_octav_fift: 0.0,
            no_crossing: 100.0,
            last_note_same: 0.5,
            mode: 0,
            interval_exists_in_harmony: 1.0,
            voice_rhythm: vec![4.0],
            voice_rhythm_patterns: Vec::new(),
            schillinger_sequence: vec![0, 3, 4, 0],
            pl: 4,
            harmony_distance_balance: 0.2,
            lookahead_depth: 2,
            beam_width: default_beam_width(),
            render_length: 2,
            rng_seed: 1.0,
            voice_contour: None,
            voice_rhythm_contour: None,
            voice_contour_resolution: 4.0,
            chord_structure: vec![0, 1, 2, 4, 5],
            harmony_distance_contour: None,
            mode_contour: None,
            root_contour: None,
            chord_structure_contour: None,
            schillinger_ex_contour: None,
            harmony_matrix_contour: None,
            melody_force_contour: None,
            harmony_matrix: None,
            mode_scales: None,
            chord_structures: None,
            main_pitch: 0,
            use_floor: false,
            use_ceiling: false,
            use_leading_voice: false,
            leading_voice_track: 0,
            leading_voice_clip: 1,
            use_resolve: false,
            root: 0,
            common_tone_penalty: 0.0,
            max_common_tones: -1,
            // Non-leader voices stick to their common tones (same_note_bonus); the
            // leader moves. min_voices_changed = 1 is a safety floor so a chord is
            // never fully static. max budget off — stickiness handles parsimony.
            min_voices_changed: 1,
            max_voices_changed: -1,
            same_note_bonus: 2.0,
            voice_contour_weight: 1.0,
            candidate_range: 3,
            chromatic_scale: Vec::new(),
            melody_force: 0.0,
            start_notes: default_start_notes(),
            roughness_weight: default_roughness_weight(),
            chord_quality_weight: 1.0,
            // 0.5 leaves the bass in root position roughly 60% of the time on a
            // default render; at 1.0 it never takes an inversion at all.
            root_position_weight: default_root_position(),
            root_doubling_weight: default_root_doubling(),
            tendency_weight: default_tendency_weight(),
            use_generated_progression: false,
            chord_templates: Vec::new(),
            metric_hold_strength: default_metric_hold_strength(),
            momentum_weight: default_momentum_weight(),
            density_weight: default_density_weight(),
            lattice_beats: 0.0,
            suspension_tolerance: default_suspension_tolerance(),
            suspension_resolve_bonus: default_suspension_resolve_bonus(),
            rhythm_generators: Vec::new(),
            rhythm_unit: default_rhythm_unit(),
            rhythm_voice_rotation: 0,
            dynamics_weight: default_dynamics_weight(),
            loop_wrap_weight: 0.0,
            cadence_weight: default_cadence_weight(),
            phrase_echo_weight: default_phrase_echo_weight(),
            fugue_mode: false,
            fugue_voice_count: default_fugue_voice_count(),
            fugue_voice_register_shifts: Vec::new(),
            fugue_repeat_subject: false,
            fugue_transform_cycle: default_fugue_transform_cycle(),
            fugue_entry_spacing: default_fugue_entry_spacing(),
            fugue_answer_interval: default_fugue_answer_interval(),
            fugue_bass_subject_shift: default_fugue_bass_subject_shift(),
            fugue_subject_anticipation: 0.0,
            fugue_entry_approach: 0.0,
            fugue_fit_to_scale: false,
            soprano_voice: 0,
            bass_voice: default_bass_voice(),
            fugue_output_tracks: default_fugue_output_tracks(),
            fugue_output_clip: default_fugue_output_clip(),
        }
    }
}

impl Config {
    pub fn randomize_contours(&mut self) {
        use crate::utils::SeededRng;

        let mut contours = Vec::new();
        // 16 voices
        for _ in 0..16 {
            // Generate 3 to 5 points
            let num_points = 3 + SeededRng::random_int(3); // 0..3 -> 0..2.99 -> 0..2. 3 + 0..2 = 3..5
            // utils.rs: (self._seeded_random(max as f64, 0.0)).floor() as i32
            // if max=8, returns 0..7.99 -> floor -> 0..7.
            // 3 + 0..7 = 3..10. Correct.

            let mut points: Vec<(f64, f64)> = Vec::new();
            let total_len = (self.render_length * 32) as f64;

            for _ in 0..num_points {
                let x = SeededRng::seeded_random(total_len, 0.0);
                let y = SeededRng::seeded_random(12.0, -12.0);
                points.push((x, y));
            }

            // Sort by x
            points.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());

            // Interpolate
            let mut contour_vec = Vec::new();
            // Calculate number of steps.
            // +1 to cover the end?
            let steps = (total_len / self.voice_contour_resolution).ceil() as usize;

            for i in 0..steps {
                let pos = (i as f64) * self.voice_contour_resolution;

                let mut y = 0.0;
                if points.is_empty() {
                    y = 0.0;
                } else if pos <= points[0].0 {
                    y = points[0].1;
                } else if pos >= points.last().unwrap().0 {
                    y = points.last().unwrap().1;
                } else {
                    // Linear interpolation
                    for j in 0..points.len() - 1 {
                        if pos >= points[j].0 && pos <= points[j + 1].0 {
                            let p1 = points[j];
                            let p2 = points[j + 1];
                            // Avoid div by zero if x matches (unlikely with random, but possible if sorted puts them close)
                            if (p2.0 - p1.0).abs() < 0.0001 {
                                y = p1.1;
                            } else {
                                let t = (pos - p1.0) / (p2.0 - p1.0);
                                y = p1.1 + t * (p2.1 - p1.1);
                            }
                            break;
                        }
                    }
                }
                contour_vec.push(y.round() as i32);
            }
            contours.push(contour_vec);
        }
        self.voice_contour = Some(contours);
    }

    pub fn init_contours(&mut self) {
        let steps = ((self.pl as f64 * 4.0 * self.render_length as f64) / self.voice_contour_resolution).ceil() as usize;
        
        let mut harmony = vec![0.2; steps];
        let mut mode = vec![0.0; steps];
        let mut chord = vec![1.0; steps];
        let mut rhythm = vec![vec![4.0; steps]; 16];

        let snaps = [0.25, 0.5, 0.75, 1.0, 2.0, 3.0, 4.0];

        for i in 0..steps {
            let phase = (i as f64) / ((steps - 1).max(1) as f64);
            let tension = (phase * std::f64::consts::PI).sin();

            // Harmony Distance: 0.2 -> 0.45 -> 0.2
            harmony[i] = 0.2 + (0.25 * tension);

            // Mode: 0.0 -> 1.0 (mid) -> 0.0
            mode[i] = if phase >= 0.4 && phase <= 0.8 { 1.0 } else { 0.0 };

            // Chord Structure: 0.0 -> 5.0 -> 0.0
            chord[i] = (tension * 5.0).round().clamp(0.0, 5.0);

            // Rhythm Fractal Predictability (Macro + Mid + Micro Phrase Alignments)
            // self.pl roughly maps towards fundamental block layouts natively framing structures predictably
            let local_phase = ((i % self.pl as usize) as f64) / (self.pl as f64).max(1.0);
            let local_tension = (local_phase * std::f64::consts::PI).sin(); // 0 -> 1 -> 0 over 1 bar
            
            let mid_phase = ((i % (self.pl as usize * 4)) as f64) / (self.pl as f64 * 4.0).max(1.0);
            let mid_tension = (mid_phase * std::f64::consts::PI).sin(); // Over 4 bars

            // Fractal composite: 40% global structure + 30% section + 30% strict local phrase
            let rhythm_tension = tension * 0.4 + mid_tension * 0.3 + local_tension * 0.3;

            // Voice Rhythm
            for v in 0..16 {
                let base_speed = if v >= 3 { 4.0 } else { 1.0 };
                // Slower at structural starts/ends locally and globally, peaks towards faster speeds logically
                let target = base_speed - rhythm_tension * (if v >= 3 { 2.0 } else { 0.75 });
                
                // Quantize to snaps
                let mut closest = snaps[0];
                let mut min_diff = (target - closest).abs();
                for &s in snaps.iter().skip(1) {
                    let diff = (target - s).abs();
                    if diff < min_diff { min_diff = diff; closest = s; }
                }
                rhythm[v][i] = closest;
            }
        }

        // Harmony Matrix: start Strict Classical(0), move to Jazz(1) at peak, back to Strict(0)
        let harmony_matrix = (0..steps).map(|i| {
            let phase = (i as f64) / ((steps - 1).max(1) as f64);
            let tension = (phase * std::f64::consts::PI).sin();
            (tension * 1.0).round().clamp(0.0, 7.0)
        }).collect();

        // Melody force: per-voice rows, flat at the scalar value so default
        // behaviour is unchanged, but the contour editor has data to shape over
        // time (one row per voice, like voice_rhythm_contour).
        let melody_force = vec![vec![self.melody_force; steps]; 16];

        self.harmony_distance_contour = Some(harmony);
        self.mode_contour = Some(mode);
        // Flat at the scalar root: default behaviour unchanged, but the contour
        // editor has data to draw modulations into (like melody_force below).
        self.root_contour = Some(vec![self.root as f64; steps]);
        self.chord_structure_contour = Some(vec![chord; 16]);
        self.voice_rhythm_contour = Some(rhythm);
        self.harmony_matrix_contour = Some(harmony_matrix);
        self.melody_force_contour = Some(melody_force);

        // Seed the editable scoring matrix with the built-in defaults so the UI
        // starts from the current values ("default should be as it is").
        if self.harmony_matrix.is_none() {
            self.harmony_matrix = Some(
                crate::harmonizer::HARMONY_MATRIX
                    .iter()
                    .map(|row| row.to_vec())
                    .collect(),
            );
        }
    }
}
